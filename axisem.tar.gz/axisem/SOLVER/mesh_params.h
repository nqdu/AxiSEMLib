! Proc  16: Header for mesh information to run static solver
! created by the mesher on 05/14/2024, at 14h 27min
 
!:::::::::::::::::::: Input parameters :::::::::::::::::::::::::::
!   Background model     :            external
!   Dominant period [s]  :    4.0000
!   Elements/wavelength  :    1.5000
!   Courant number       :    0.6000
!   Coarsening levels    :         3
!:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
 
 integer, parameter ::         npol =         4  !            polynomial order
 integer, parameter ::        nelem =     37264  !                   proc. els
 integer, parameter ::       npoint =    931600  !               proc. all pts
 integer, parameter ::    nel_solid =     31212  !             proc. solid els
 integer, parameter ::    nel_fluid =      6052  !             proc. fluid els
 integer, parameter :: npoint_solid =    780300  !             proc. solid pts
 integer, parameter :: npoint_fluid =    151300  !             proc. fluid pts
 integer, parameter ::  nglob_fluid =     98558  !            proc. flocal pts
 integer, parameter ::     nel_bdry =       408  ! proc. solid-fluid bndry els
 integer, parameter ::        ndisc =         3  !   # disconts in bkgrd model
 integer, parameter ::   nproc_mesh =        16  !        number of processors
 integer, parameter :: lfbkgrdmodel =         8  !   length of bkgrdmodel name
 
!:::::::::::::::::::: Output parameters ::::::::::::::::::::::::::
!   Time step [s]        :    0.0247
!   Min(h/vp),dt/courant :    0.2378    0.1650
!   max(h/vs),T0/wvlngth :    2.6643    2.6667
!   Inner core r_min [km]:  782.4284
!   Max(h) r/ns(icb) [km]:    7.0282
!   Max(h) precalc.  [km]:    7.1389
!:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
 
