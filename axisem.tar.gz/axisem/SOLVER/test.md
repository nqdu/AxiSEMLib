```bash
for i,j 
    for m,n 
        compute f_ij(xi_m,eta_n) = l_i(xi_m) l_j(eta_n)
    compute d(x,z) f_ij at (m,n) = w 
    out = sum(w * coef)
```