import numpy as np 
import matplotlib.pyplot as plt 
from tqdm import tqdm
from sem_mesh import set_sem_model

def smooth_pde(NGLL,sigma,model_list = ['vp','vs','rho'],model1d = 'ak135'):
    # get gll arrays
    from libgll import get_gll
    xgll,wxgll,hprime = get_gll(NGLL)

    # get model
    model,xx,jaco,xix,ibool,core_string = set_sem_model(NGLL,model_list,model1d)
    nglob = np.max(ibool) + 1
    nspec = xx.shape[0]
    nm = model.shape[-1]

    # rmassinv
    rmassinv = np.zeros((nglob,1))
    for ispec in range(nspec):
        mass = wxgll * jaco[ispec,:]
        for igll in range(NGLL):
            iglob = ibool[ispec,igll]
            rmassinv[iglob] += mass[igll]
    rmassinv = 1. / rmassinv

    # prepare C tensor
    dmin = np.unique(np.diff(xx.flatten()))[1]
    dt = 1.0 / 12 * dmin * dmin 
    nt = int(sigma**2 / ( 2 * dt)) + 1
    c = dt

    # get average model
    counter = np.zeros((nglob,1),dtype=float)
    displ = np.zeros((nglob,nm))
    xstore = counter * 1.
    for ispec in range(nspec):
        for igll in range(NGLL):
            iglob = ibool[ispec,igll]
            for im in range(nm):
                displ[iglob,im] += model[ispec,igll,im]
            counter[iglob] += 1.
            xstore[iglob] = xx[ispec,igll]
    displ /= counter

    # smooth begin
    print('smoothing begin ...')
    # smoothing
    for it in tqdm(range(nt)):
        accel = np.zeros((nglob,nm))

        for ispec in range(nspec):
            idx = ibool[ispec,:]
            for im in range(nm):
                u = displ[idx,im]
                s = c * np.dot(hprime,u) * xix[ispec,:]
                f = np.dot(s*jaco[ispec,:] * xix[ispec,:] * wxgll,hprime)
                accel[idx,im] -= f
        
        # apply mass matrix
        accel *= rmassinv
        displ += accel
    
    return model,xx,xstore,displ,core_string


def main():
    # set parameters
    sigma = 5. # gauss smoothing parameters, in km
    NGLL = 5 
    model_list = ['vp','vs','rho']
    model1d = 'ak135'

    # smooth
    model,xx,xstore,displ,core_string = smooth_pde(NGLL,sigma,model_list,model1d)
    nglob = len(xstore)

    # write axisem external model
    f = open(f"{model1d}.smooth.bm","w")
    f.write(f"NAME {model1d}_smooth\n")
    f.write("ANELASTIC       T\n")
    f.write("ANISOTROPIC     T\n")
    f.write('UNITS           m\n')
    f.write("COLUMNS       radius      rho      vpv      vsv      qka      qmu      vph      vsh      eta\n")

    for iglob in range(nglob):
        vp0,vs0,rho0 = displ[iglob,:]
        f.write("\t %f %f %f %f %f %f %f %f %f\n"%(6371000 - 1000*xstore[iglob,0],rho0,vp0,vs0,
                                                9999.,9999.,vp0,vs0,1.))
    f.write(core_string)

    f = open(f"{model1d}.txt","w")
    for i in range(nglob):
        f.write("%f " %(-xstore[i,0]))
        for im in range(model.shape[-1]):
            f.write("%f " %(displ[i,im]))
        f.write("\n")
    f.close()

    plt.figure(1,figsize=(6,14))
    plt.plot(displ[:,1] / 1000,-xstore.flatten())
    plt.plot(model[:,:,1].flatten()/1000,-xx.flatten())
    plt.savefig("smooth.jpg")

main()


