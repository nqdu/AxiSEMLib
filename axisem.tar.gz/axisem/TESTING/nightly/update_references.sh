#/bin/bash
cp test_01/new_data/axisem.mseed test_01/ref_data/axisem.mseed 
cp test_02/new_data/axisem.mseed test_02/ref_data/axisem.mseed 
cp test_03/new_data/axisem.mseed test_03/ref_data/axisem.mseed 
